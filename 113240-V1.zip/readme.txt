May 29, 2008

1. extract all files from .zip file into same directory
2. to reproduce all results from the paper type: do kz_demandelasts_aer08_onebutton_tables.do
